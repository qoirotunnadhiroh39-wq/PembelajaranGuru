import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const assessmentGrid = [
  // Berpikir Komputasional
  {
    no: 1,
    cp: "1.1",
    cpDeskripsi: "Berpikir Komputasional",
    tp: "1.1",
    tpDeskripsi: "Peserta didik mampu memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari",
    materi: "Himpunan Data Terstruktur",
    indikator: "Siswa dapat memahami dan mengidentifikasi data terstruktur dalam kehidupan sehari-hari",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "9"
  },
  {
    no: 2,
    cp: "1.1",
    cpDeskripsi: "Berpikir Komputasional", 
    tp: "1.1",
    tpDeskripsi: "Peserta didik mampu menuliskan sekumpulan instruksi dengan menggunakan sekumpulan kosakata terbatas atau simbol dalam format pseudocode",
    materi: "Algoritma dan Pseudocode",
    indikator: "Siswa dapat membuat algoritma sederhana untuk menyelesaikan masalah matematis",
    bentukSoal: "Essay",
    nomorSoal: "2"
  },

  // Literasi Digital - Mesin Pencari
  {
    no: 3,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1", 
    tpDeskripsi: "Peserta didik mampu memahami cara kerja dan penggunaan mesin pencari di internet",
    materi: "Mesin Pencari Internet",
    indikator: "Siswa dapat memahami protokol browsing internet",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "4"
  },

  // Literasi Digital - Kredibilitas Informasi
  {
    no: 4,
    cp: "2.2",
    cpDeskripsi: "Literasi Digital",
    tp: "2.2",
    tpDeskripsi: "Mengetahui kredibilitas sumber informasi digital dan mengenal ekosistem media pers digital",
    materi: "Kredibilitas Informasi Digital",
    indikator: "Siswa dapat mengidentifikasi platform media sosial yang kredibel",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "10"
  },

  // Literasi Digital - Fakta dan Opini
  {
    no: 5,
    cp: "2.3",
    cpDeskripsi: "Literasi Digital",
    tp: "2.3",
    tpDeskripsi: "Membedakan fakta dan opini",
    materi: "Literasi Informasi",
    indikator: "Siswa dapat memahami etika dalam berkomunikasi digital",
    bentukSoal: "Essay",
    nomorSoal: "3"
  },

  // Pemanfaatan Teknologi Digital
  {
    no: 6,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Memahami pemanfaatan perkakas teknologi digital untuk membuat laporan, presentasi, serta analisis dan interpretasi data",
    materi: "Aplikasi Perkantoran",
    indikator: "Siswa dapat mengidentifikasi software pengolah kata",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "3"
  },

  // Komponen dan Cara Kerja Komputer
  {
    no: 7,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer",
    materi: "Komponen Komputer",
    indikator: "Siswa dapat mengidentifikasi fungsi processor sebagai otak komputer",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "2"
  },
  {
    no: 8,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1", 
    tpDeskripsi: "Mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer",
    materi: "Memori Komputer",
    indikator: "Siswa dapat menjelaskan fungsi RAM dalam sistem komputer",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "8"
  },
  {
    no: 9,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer",
    materi: "Perangkat Input/Output",
    indikator: "Siswa dapat membedakan perangkat input dan output",
    bentukSoal: "Pilihan Ganda", 
    nomorSoal: "5, 15"
  },
  {
    no: 10,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer",
    materi: "Hardware vs Software",
    indikator: "Siswa dapat menganalisis perbedaan hardware dan software",
    bentukSoal: "Essay",
    nomorSoal: "1"
  },

  // Konektivitas Jaringan
  {
    no: 11,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital", 
    tp: "2.1",
    tpDeskripsi: "Memahami konsep dan penerapan konektivitas jaringan lokal dan internet baik kabel maupun nirkabel",
    materi: "Jaringan Komputer",
    indikator: "Siswa dapat membedakan jenis jaringan LAN, MAN, WAN",
    bentukSoal: "Essay",
    nomorSoal: "5"
  },
  {
    no: 12,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Memahami konsep dan penerapan konektivitas jaringan lokal dan internet",
    materi: "Keamanan Jaringan",
    indikator: "Siswa dapat memahami fungsi firewall dalam mengatur lalu lintas jaringan",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "14"
  },

  // Ruang Publik Virtual
  {
    no: 13,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1", 
    tpDeskripsi: "Mengetahui jenis ruang publik virtual",
    materi: "Cloud Computing",
    indikator: "Siswa dapat memahami konsep komputasi awan",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "12"
  },

  // Media Digital untuk Produksi Konten
  {
    no: 14,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Memahami pemanfaatan media digital untuk produksi dan diseminasi konten",
    materi: "Format File Digital",
    indikator: "Siswa dapat mengidentifikasi ekstensi file untuk berbagai jenis konten",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "6"
  },
  {
    no: 15,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Memahami pemanfaatan media digital untuk produksi dan diseminasi konten",
    materi: "Teknologi Web",
    indikator: "Siswa dapat memahami bahasa markup untuk pembuatan konten web",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "13"
  },

  // Keamanan Digital - Rekam Jejak Digital
  {
    no: 16,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Memahami pentingnya menjaga rekam jejak digital",
    materi: "Rekam Jejak Digital",
    indikator: "Siswa dapat memahami cara penyebaran virus komputer",
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "11"
  },

  // Sistem Operasi
  {
    no: 17,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1", 
    tpDeskripsi: "Mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer",
    materi: "Sistem Operasi",
    indikator: "Siswa dapat menganalisis fungsi dan memberikan contoh sistem operasi",
    bentukSoal: "Essay",
    nomorSoal: "4"
  },
  {
    no: 18,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer",
    materi: "Sistem Operasi",
    indikator: "Siswa dapat mengidentifikasi contoh sistem operasi",
    bentukSoal: "Pilihan Ganda", 
    nomorSoal: "7"
  },

  // Konsep Dasar TIK
  {
    no: 19,
    cp: "2.1",
    cpDeskripsi: "Literasi Digital",
    tp: "2.1",
    tpDeskripsi: "Memahami konsep dasar teknologi informasi dan komunikasi",
    materi: "Pengenalan TIK",
    indikator: "Siswa dapat menjelaskan pengertian dan kepanjangan TIK", 
    bentukSoal: "Pilihan Ganda",
    nomorSoal: "1"
  }
];

export function KisiKisi() {
  return (
    <Card className="shadow-educational">
      <CardHeader className="bg-gradient-educational text-primary-foreground">
        <CardTitle className="text-xl">Kisi-Kisi Sumatif Tengah Semester (PTS)</CardTitle>
        <p className="text-sm opacity-90">Mata Pelajaran: Informatika - Tahun Ajaran 2025</p>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-12 text-center font-semibold">No</TableHead>
                <TableHead className="min-w-[120px] font-semibold">Elemen</TableHead>
                <TableHead className="w-16 text-center font-semibold">Kode CP</TableHead>
                <TableHead className="w-16 text-center font-semibold">Kode TP</TableHead>
                <TableHead className="min-w-[200px] font-semibold">Tujuan Pembelajaran (TP)</TableHead>
                <TableHead className="min-w-[150px] font-semibold">Materi</TableHead>
                <TableHead className="min-w-[200px] font-semibold">Indikator</TableHead>
                <TableHead className="w-32 text-center font-semibold">Bentuk Soal</TableHead>
                <TableHead className="w-24 text-center font-semibold">No. Soal</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assessmentGrid.map((item) => (
                <TableRow key={item.no} className="hover:bg-muted/30 transition-colors">
                  <TableCell className="text-center font-medium text-primary">
                    {item.no}
                  </TableCell>
                  <TableCell className="font-medium text-accent">
                    {item.cpDeskripsi}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline" className="text-xs">
                      {item.cp}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline" className="text-xs">
                      {item.tp}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">
                    {item.tpDeskripsi}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="whitespace-nowrap">
                      {item.materi}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">
                    {item.indikator}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge 
                      variant={item.bentukSoal === "Pilihan Ganda" ? "default" : "secondary"}
                      className="whitespace-nowrap"
                    >
                      {item.bentukSoal}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center font-medium">
                    {item.nomorSoal}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        {/* Summary */}
        <div className="p-6 bg-gradient-subtle border-t">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="p-4 bg-white rounded-lg shadow-soft">
              <p className="text-2xl font-bold text-primary">15</p>
              <p className="text-sm text-muted-foreground">Soal Pilihan Ganda</p>
            </div>
            <div className="p-4 bg-white rounded-lg shadow-soft">
              <p className="text-2xl font-bold text-accent">5</p>
              <p className="text-sm text-muted-foreground">Soal Essay</p>
            </div>
            <div className="p-4 bg-white rounded-lg shadow-soft">
              <p className="text-2xl font-bold text-success">100</p>
              <p className="text-sm text-muted-foreground">Total Nilai</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}