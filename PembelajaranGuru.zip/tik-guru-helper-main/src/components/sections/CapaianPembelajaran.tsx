import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const learningData = [
  {
    no: 1,
    elemen: "Berpikir Komputasional",
    capaianPembelajaran: "Peserta didik mampu memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari, memahami konsep lembar kerja pengolah data dan menerapkan berpikir komputasional dalam menyelesaikan persoalan yang mengandung himpunan data berstruktur sederhana dengan volume kecil, dan mendisposisikan berpikir komputasional yang diperlukan pada berbagai bidang; mampu menuliskan sekumpulan instruksi dengan menggunakan sekumpulan kosakata terbatas atau simbol dalam format pseudocode",
    tujuanPembelajaran: [
      {
        kode: "1.1",
        deskripsi: "Peserta didik mampu memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari"
      }
    ],
    semester: 1
  },
  {
    no: 2,
    elemen: "Literasi Digital",
    capaianPembelajaran: "Peserta didik mampu memahami cara kerja dan penggunaan mesin pencari di internet; mengetahui kredibilitas sumber informasi digital dan mengenal ekosistem media pers digital; membedakan fakta dan opini; memahami pemanfaatan perkakas teknologi digital untuk membuat laporan, presentasi, serta analisis dan interpretasi data; mampu mendeskripsikan komponen, fungsi, dan cara kerja komputer; memahami konsep dan penerapan konektivitas jaringan lokal dan internet baik kabel maupun nirkabel; dan mengetahui jenis ruang publik virtual; memahami pemanfaatan media digital untuk produksi dan diseminasi konten. Peserta didik mampu memahami pentingnya menjaga rekam jejak digital, mengamalkan toleransi dan empati di dunia digital, memahami dampak perundungan digital, membuat kata sandi yang aman, memahami pengamanan perangkat dari berbagai jenis malware, memilah informasi yang bersifat privat dan publik, melindungi data pribadi dan identitas digital, serta memiliki kesadaran penuh (mindfulness) dalam dunia digital",
    tujuanPembelajaran: [
      {
        kode: "2.1",
        deskripsi: "Peserta didik mampu memahami cara kerja dan penggunaan mesin pencari di internet"
      },
      {
        kode: "2.2",
        deskripsi: "mengetahui kredibilitas sumber informasi digital dan mengenal ekosistem media pers digital"
      },
      {
        kode: "2.3",
        deskripsi: "membedakan fakta dan opini"
      }
    ],
    semester: 1
  }
];

export function CapaianPembelajaran() {
  return (
    <Card className="shadow-educational">
      <CardHeader className="bg-gradient-educational text-primary-foreground">
        <CardTitle className="text-xl">Capaian Pembelajaran & Tujuan Pembelajaran TIK 2025</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-16 text-center font-semibold">No</TableHead>
                <TableHead className="min-w-[150px] font-semibold">Elemen</TableHead>
                <TableHead className="min-w-[300px] font-semibold">Capaian Pembelajaran (CP)</TableHead>
                <TableHead className="min-w-[250px] font-semibold">Tujuan Pembelajaran (TP)</TableHead>
                <TableHead className="w-24 text-center font-semibold">Semester</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {learningData.map((item) => (
                <TableRow key={item.no} className="hover:bg-muted/30 transition-colors">
                  <TableCell className="text-center font-medium text-primary">
                    {item.no}
                  </TableCell>
                  <TableCell className="font-medium text-accent">
                    {item.elemen}
                  </TableCell>
                  <TableCell className="text-sm">
                    {item.capaianPembelajaran}
                  </TableCell>
                  <TableCell>
                    <ul className="space-y-2">
                      {item.tujuanPembelajaran.map((tp, index) => (
                        <li key={index} className="flex items-start">
                          <span className="inline-block px-2 py-1 bg-primary text-primary-foreground rounded text-xs font-medium mr-2 flex-shrink-0">
                            {tp.kode}
                          </span>
                          <span className="text-sm">{tp.deskripsi}</span>
                        </li>
                      ))}
                    </ul>
                  </TableCell>
                  <TableCell className="text-center font-medium">
                    {item.semester}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}