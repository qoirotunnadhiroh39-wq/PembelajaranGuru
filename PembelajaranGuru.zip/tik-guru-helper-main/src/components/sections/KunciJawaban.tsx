import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, XCircle, RotateCcw } from "lucide-react";

const correctAnswers = {
  multipleChoice: ["A", "C", "B", "B", "C", "B", "C", "C", "B", "B", "A", "B", "A", "C", "D"],
  essay: [
    "Hardware adalah komponen fisik yang dapat dilihat dan disentuh seperti CPU, RAM, keyboard. Software adalah program atau aplikasi yang tidak dapat dilihat secara fisik seperti Windows, Microsoft Word, antivirus.",
    "Algoritma adalah urutan langkah-langkah logis untuk menyelesaikan masalah. Algoritma luas persegi panjang: 1) Input panjang, 2) Input lebar, 3) Hitung luas = panjang × lebar, 4) Output hasil luas.",
    "1) Tidak menyebarkan informasi palsu, 2) Menghormati privasi orang lain, 3) Tidak melakukan cyberbullying, 4) Menggunakan bahasa yang sopan, 5) Tidak melanggar hak cipta.",
    "Sistem operasi berfungsi mengelola perangkat keras, menjalankan program aplikasi, dan menyediakan antarmuka pengguna. Contoh: Windows, Linux, macOS.",
    "Jaringan komputer adalah kumpulan komputer yang terhubung untuk berbagi data. LAN (Local Area Network) = jaringan lokal dalam gedung, MAN (Metropolitan Area Network) = jaringan kota, WAN (Wide Area Network) = jaringan luas antar kota/negara."
  ]
};

export function KunciJawaban() {
  const [studentAnswers, setStudentAnswers] = useState<{
    multipleChoice: string[];
    essay: string[];
  }>({
    multipleChoice: Array(15).fill(""),
    essay: Array(5).fill("")
  });
  
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  const handleMultipleChoiceChange = (index: number, value: string) => {
    const newAnswers = [...studentAnswers.multipleChoice];
    newAnswers[index] = value.toUpperCase();
    setStudentAnswers({ ...studentAnswers, multipleChoice: newAnswers });
  };

  const handleEssayChange = (index: number, value: string) => {
    const newAnswers = [...studentAnswers.essay];
    newAnswers[index] = value;
    setStudentAnswers({ ...studentAnswers, essay: newAnswers });
  };

  const calculateScore = () => {
    let correctMC = 0;
    let correctEssay = 0;

    // Calculate multiple choice score
    studentAnswers.multipleChoice.forEach((answer, index) => {
      if (answer === correctAnswers.multipleChoice[index]) {
        correctMC++;
      }
    });

    // Calculate essay score (simplified - checks if answer contains key words)
    studentAnswers.essay.forEach((answer, index) => {
      if (answer.trim().length > 20) { // Basic check for meaningful answer
        correctEssay++;
      }
    });

    const totalScore = ((correctMC * 4) + (correctEssay * 12)); // MC = 4 points each, Essay = 12 points each
    setScore(totalScore);
    setShowResults(true);
  };

  const resetAnswers = () => {
    setStudentAnswers({
      multipleChoice: Array(15).fill(""),
      essay: Array(5).fill("")
    });
    setShowResults(false);
    setScore(0);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="shadow-educational">
        <CardHeader className="bg-gradient-educational text-primary-foreground">
          <CardTitle className="text-xl">Blanko Kunci Jawaban PTS Informatika</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="space-y-2">
              <p className="text-sm"><strong>Nama:</strong> ___________________________</p>
              <p className="text-sm"><strong>Kelas:</strong> ___________________________</p>
              <p className="text-sm"><strong>No. Absen:</strong> ___________________________</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={calculateScore} className="bg-success hover:bg-success/90">
                Hitung Nilai
              </Button>
              <Button onClick={resetAnswers} variant="outline">
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
          
          {showResults && (
            <div className="mt-4 p-4 bg-gradient-subtle border border-primary/20 rounded-lg">
              <div className="flex items-center gap-2">
                <Badge variant="default" className="text-lg px-4 py-2">
                  Nilai: {score}/100
                </Badge>
                <Badge variant={score >= 75 ? "default" : score >= 60 ? "secondary" : "destructive"}>
                  {score >= 75 ? "Tuntas" : score >= 60 ? "Cukup" : "Perlu Remedial"}
                </Badge>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Multiple Choice Section */}
      <Card className="shadow-educational">
        <CardHeader className="bg-primary/10">
          <CardTitle className="text-lg">Bagian A: Pilihan Ganda (60 Poin)</CardTitle>
          <p className="text-sm text-muted-foreground">Pilih jawaban yang paling tepat (A, B, C, atau D)</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-10 gap-4">
            {Array.from({ length: 15 }, (_, index) => (
              <div key={index} className="space-y-2">
                <Label className="text-sm font-medium">{index + 1}.</Label>
                <Input
                  type="text"
                  maxLength={1}
                  className={`text-center font-bold ${
                    showResults 
                      ? studentAnswers.multipleChoice[index] === correctAnswers.multipleChoice[index]
                        ? "bg-success/20 border-success"
                        : "bg-destructive/20 border-destructive"
                      : ""
                  }`}
                  value={studentAnswers.multipleChoice[index]}
                  onChange={(e) => handleMultipleChoiceChange(index, e.target.value)}
                  placeholder="?"
                />
                {showResults && (
                  <div className="flex items-center justify-center">
                    {studentAnswers.multipleChoice[index] === correctAnswers.multipleChoice[index] ? (
                      <CheckCircle className="h-4 w-4 text-success" />
                    ) : (
                      <div className="text-center">
                        <XCircle className="h-4 w-4 text-destructive mx-auto" />
                        <span className="text-xs text-success">{correctAnswers.multipleChoice[index]}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Essay Section */}
      <Card className="shadow-educational">
        <CardHeader className="bg-accent/10">
          <CardTitle className="text-lg">Bagian B: Essay (40 Poin)</CardTitle>
          <p className="text-sm text-muted-foreground">Jawab dengan lengkap dan jelas</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            {Array.from({ length: 5 }, (_, index) => (
              <div key={index} className="space-y-3">
                <Label className="text-sm font-medium">Soal {index + 1}</Label>
                <Textarea
                  placeholder="Tulis jawaban Anda di sini..."
                  className="min-h-[100px]"
                  value={studentAnswers.essay[index]}
                  onChange={(e) => handleEssayChange(index, e.target.value)}
                />
                {showResults && (
                  <div className="p-3 bg-accent/10 rounded border border-accent/20">
                    <p className="text-sm font-medium text-accent mb-2">Kunci Jawaban:</p>
                    <p className="text-sm text-muted-foreground">{correctAnswers.essay[index]}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}