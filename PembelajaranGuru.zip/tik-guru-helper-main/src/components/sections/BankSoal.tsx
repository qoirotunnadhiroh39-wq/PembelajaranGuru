import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

const multipleChoiceQuestions = [
  {
    no: 1,
    question: "Apa kepanjangan dari TIK?",
    options: ["A. Teknologi Informasi dan Komunikasi", "B. Teknik Informasi Komputer", "C. Teknologi Internet dan Komputer", "D. Teknik Informasi dan Komunikasi"],
    answer: "A"
  },
  {
    no: 2,
    question: "Perangkat keras yang berfungsi sebagai otak komputer adalah...",
    options: ["A. RAM", "B. Hard Disk", "C. Processor", "D. Monitor"],
    answer: "C"
  },
  {
    no: 3,
    question: "Software yang digunakan untuk mengolah kata adalah...",
    options: ["A. Microsoft Excel", "B. Microsoft Word", "C. Microsoft PowerPoint", "D. Adobe Photoshop"],
    answer: "B"
  },
  {
    no: 4,
    question: "Protokol yang digunakan untuk browsing internet adalah...",
    options: ["A. FTP", "B. HTTP", "C. SMTP", "D. POP3"],
    answer: "B"
  },
  {
    no: 5,
    question: "Perangkat input pada komputer adalah...",
    options: ["A. Speaker", "B. Monitor", "C. Keyboard", "D. Printer"],
    answer: "C"
  },
  {
    no: 6,
    question: "Ekstensi file gambar yang umum digunakan adalah...",
    options: ["A. .txt", "B. .jpg", "C. .doc", "D. .exe"],
    answer: "B"
  },
  {
    no: 7,
    question: "Perangkat lunak sistem operasi adalah...",
    options: ["A. Microsoft Office", "B. Adobe Reader", "C. Windows 10", "D. Google Chrome"],
    answer: "C"
  },
  {
    no: 8,
    question: "Fungsi dari RAM adalah...",
    options: ["A. Menyimpan data permanen", "B. Menampilkan gambar", "C. Menyimpan data sementara", "D. Memproses data"],
    answer: "C"
  },
  {
    no: 9,
    question: "Algoritma adalah...",
    options: ["A. Bahasa pemrograman", "B. Langkah-langkah logis untuk menyelesaikan masalah", "C. Perangkat keras komputer", "D. Software aplikasi"],
    answer: "B"
  },
  {
    no: 10,
    question: "Yang termasuk media sosial adalah...",
    options: ["A. Microsoft Word", "B. Instagram", "C. Windows", "D. Google Drive"],
    answer: "B"
  },
  {
    no: 11,
    question: "Virus komputer dapat menyebar melalui...",
    options: ["A. Email dan USB", "B. Monitor", "C. Keyboard", "D. Mouse"],
    answer: "A"
  },
  {
    no: 12,
    question: "Cloud computing adalah...",
    options: ["A. Penyimpanan lokal", "B. Komputasi awan", "C. Perangkat keras", "D. Software antivirus"],
    answer: "B"
  },
  {
    no: 13,
    question: "HTML adalah kepanjangan dari...",
    options: ["A. Hypertext Markup Language", "B. High Tech Modern Language", "C. Home Tool Markup Language", "D. Hyperlink and Text Markup Language"],
    answer: "A"
  },
  {
    no: 14,
    question: "Fungsi dari firewall adalah...",
    options: ["A. Mempercepat internet", "B. Melindungi dari virus", "C. Mengatur lalu lintas jaringan", "D. Menyimpan data"],
    answer: "C"
  },
  {
    no: 15,
    question: "Yang termasuk perangkat output adalah...",
    options: ["A. Mouse", "B. Webcam", "C. Microphone", "D. Printer"],
    answer: "D"
  }
];

const essayQuestions = [
  {
    no: 1,
    question: "Jelaskan perbedaan antara perangkat keras (hardware) dan perangkat lunak (software) dalam sistem komputer! Berikan masing-masing 3 contoh!",
    answer: "Hardware adalah komponen fisik yang dapat dilihat dan disentuh seperti CPU, RAM, keyboard. Software adalah program atau aplikasi yang tidak dapat dilihat secara fisik seperti Windows, Microsoft Word, antivirus."
  },
  {
    no: 2,
    question: "Apa yang dimaksud dengan algoritma? Buatlah algoritma sederhana untuk menghitung luas persegi panjang!",
    answer: "Algoritma adalah urutan langkah-langkah logis untuk menyelesaikan masalah. Algoritma luas persegi panjang: 1) Input panjang, 2) Input lebar, 3) Hitung luas = panjang × lebar, 4) Output hasil luas."
  },
  {
    no: 3,
    question: "Sebutkan dan jelaskan minimal 4 etika dalam menggunakan internet yang harus dipatuhi oleh siswa!",
    answer: "1) Tidak menyebarkan informasi palsu, 2) Menghormati privasi orang lain, 3) Tidak melakukan cyberbullying, 4) Menggunakan bahasa yang sopan, 5) Tidak melanggar hak cipta."
  },
  {
    no: 4,
    question: "Jelaskan fungsi dari sistem operasi pada komputer dan sebutkan 3 contoh sistem operasi yang populer!",
    answer: "Sistem operasi berfungsi mengelola perangkat keras, menjalankan program aplikasi, dan menyediakan antarmuka pengguna. Contoh: Windows, Linux, macOS."
  },
  {
    no: 5,
    question: "Apa yang dimaksud dengan jaringan komputer? Jelaskan perbedaan antara LAN, MAN, dan WAN!",
    answer: "Jaringan komputer adalah kumpulan komputer yang terhubung untuk berbagi data. LAN (Local Area Network) = jaringan lokal dalam gedung, MAN (Metropolitan Area Network) = jaringan kota, WAN (Wide Area Network) = jaringan luas antar kota/negara."
  }
];

export function BankSoal() {
  return (
    <div className="space-y-8">
      {/* Multiple Choice Section */}
      <Card className="shadow-educational">
        <CardHeader className="bg-gradient-educational text-primary-foreground">
          <CardTitle className="text-xl flex items-center gap-2">
            Soal Pilihan Ganda
            <Badge variant="secondary" className="bg-white/20 text-primary-foreground">
              15 Butir
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            {multipleChoiceQuestions.map((q) => (
              <div key={q.no} className="border-l-4 border-primary pl-4">
                <div className="flex items-start gap-2 mb-3">
                  <Badge variant="outline" className="min-w-8 h-6 flex items-center justify-center">
                    {q.no}
                  </Badge>
                  <p className="font-medium text-foreground">{q.question}</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 ml-10">
                  {q.options.map((option, index) => (
                    <div
                      key={index}
                      className={`p-2 rounded border transition-colors ${
                        option.startsWith(q.answer) 
                          ? "bg-success/10 border-success text-success-foreground" 
                          : "bg-muted/30 border-border"
                      }`}
                    >
                      {option}
                    </div>
                  ))}
                </div>
                <div className="mt-2 ml-10">
                  <Badge variant="default" className="bg-success">
                    Kunci: {q.answer}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Essay Section */}
      <Card className="shadow-educational">
        <CardHeader className="bg-gradient-educational text-primary-foreground">
          <CardTitle className="text-xl flex items-center gap-2">
            Soal Essay
            <Badge variant="secondary" className="bg-white/20 text-primary-foreground">
              5 Butir
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-8">
            {essayQuestions.map((q) => (
              <div key={q.no} className="border-l-4 border-accent pl-4">
                <div className="flex items-start gap-2 mb-4">
                  <Badge variant="outline" className="min-w-8 h-6 flex items-center justify-center">
                    {q.no}
                  </Badge>
                  <p className="font-medium text-foreground">{q.question}</p>
                </div>
                <div className="ml-10">
                  <p className="text-sm font-medium text-accent mb-2">Kunci Jawaban:</p>
                  <div className="p-4 bg-accent/10 border-l-4 border-accent rounded-r">
                    <p className="text-sm text-foreground">{q.answer}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}