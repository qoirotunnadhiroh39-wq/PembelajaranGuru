import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { GraduationCap, FileText, ClipboardCheck, Table } from "lucide-react";

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const navigationItems = [
  {
    id: "capaian",
    title: "Capaian & Tujuan Pembelajaran",
    description: "Tabel CP dan TP",
    icon: GraduationCap,
  },
  {
    id: "bank-soal",
    title: "Bank Soal PTS",
    description: "15 Pilihan Ganda + 5 Essay",
    icon: FileText,
  },
  {
    id: "kunci-jawaban",
    title: "Blanko Kunci Jawaban",
    description: "Jawaban & Penilaian",
    icon: ClipboardCheck,
  },
  {
    id: "kisi-kisi",
    title: "Kisi-Kisi Sumatif",
    description: "Tabel Assessment Grid",
    icon: Table,
  },
];

export function Navigation({ activeSection, onSectionChange }: NavigationProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {navigationItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeSection === item.id;
        
        return (
          <Card
            key={item.id}
            className={`cursor-pointer transition-all duration-200 hover:shadow-educational ${
              isActive ? "ring-2 ring-primary bg-gradient-educational text-primary-foreground" : "hover:scale-105"
            }`}
            onClick={() => onSectionChange(item.id)}
          >
            <div className="p-6 text-center">
              <Icon className={`h-8 w-8 mx-auto mb-3 ${isActive ? "text-primary-foreground" : "text-primary"}`} />
              <h3 className={`font-semibold text-sm mb-1 ${isActive ? "text-primary-foreground" : "text-foreground"}`}>
                {item.title}
              </h3>
              <p className={`text-xs ${isActive ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                {item.description}
              </p>
            </div>
          </Card>
        );
      })}
    </div>
  );
}