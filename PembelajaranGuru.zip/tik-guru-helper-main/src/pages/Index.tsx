import React, { useState } from 'react';
import { Navigation } from "@/components/ui/navigation";
import { CapaianPembelajaran } from "@/components/sections/CapaianPembelajaran";
import { BankSoal } from "@/components/sections/BankSoal";
import { KunciJawaban } from "@/components/sections/KunciJawaban";
import { KisiKisi } from "@/components/sections/KisiKisi";
import { GraduationCap } from "lucide-react";

const Index = () => {
  const [activeSection, setActiveSection] = useState("capaian");

  const renderSection = () => {
    switch (activeSection) {
      case "capaian":
        return <CapaianPembelajaran />;
      case "bank-soal":
        return <BankSoal />;
      case "kunci-jawaban":
        return <KunciJawaban />;
      case "kisi-kisi":
        return <KisiKisi />;
      default:
        return <CapaianPembelajaran />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="bg-white shadow-soft border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-educational rounded-lg">
              <GraduationCap className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">TP TIK 2025</h1>
              <p className="text-sm text-muted-foreground">Sistem Manajemen Pembelajaran Informatika</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Navigation activeSection={activeSection} onSectionChange={setActiveSection} />
        <div className="animate-in fade-in-50 duration-300">
          {renderSection()}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="container mx-auto px-4 py-6 text-center">
          <p className="text-sm text-muted-foreground">
            © 2025 TP TIK - Sistem Pembelajaran Informatika
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
